//
// Created by sophie on 18/02/2020.
//

#ifndef MATRICEVECTEUR_FONCTIONS_H
#define MATRICEVECTEUR_FONCTIONS_H
void generation_vecteur(int n, int* vecteur, int nb_zero);
void matrice_vecteur(int n, int* matrice, int* v1, int* v2);

#endif //MATRICEVECTEUR_FONCTIONS_H
