//
// Created by sophie on 18/02/2020.
//

#ifndef SYRACUSE_SYRACUSE_H
#define SYRACUSE_SYRACUSE_H
int test_syracuse(int n, int *tab);
void syracuse(int n, int *tab);
void non_syracuse(int n, int *tab);
void demi_syracuse(int n, int *tab);
#endif //SYRACUSE_SYRACUSE_H
